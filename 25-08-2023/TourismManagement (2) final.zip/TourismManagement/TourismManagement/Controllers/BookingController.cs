﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TourismManagement.Models;
using TourismManagement.Services;
using TourismManagement.Services.Interface;

namespace TourismManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        public IBooking _booking;

        public BookingController(IBooking booking)
        {
            _booking = booking;
        }

        [HttpGet("{customerName}")]
        public async Task<ActionResult<List<Bookingtable>>> GetBookingsByCustomerName(string customerName)
        {
            var bookings = await _booking.GetBookingsByCustomerNameAsync(customerName);
            if (bookings == null || bookings.Count == 0)
            {
                return NotFound();
            }
            return Ok(bookings);
        }

        [HttpPost]
        public async Task<ActionResult<BookingDetail>> AddBooking(BookingDetail bookingDetails)
        {

            var packages = await _booking.AddBooking(bookingDetails);
            return Ok(packages);
        }

    }
}
