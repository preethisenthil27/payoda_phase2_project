﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TourismManagement.Models;
using TourismManagement.Services.Interface;

namespace TourismManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        public ILogin _login;

        public LoginController(ILogin login)
        {
            _login = login;
        }
        [HttpPost("Register")]
        public async Task<ActionResult<List<Credentail>>> RegisterDetails(Credentail userDetails)
        {
            var userdetails = await _login.RegisterDetails(userDetails);
            return Ok(userdetails);
        }
        /*
        [HttpPost("Login")]
        public async Task<ActionResult<Credentail>> Logindetail(Login login)
        {
           // var credentail=await _login.Logindetails(login);
            try
            { 
              var credentail = await _login.Logindetails(login);
                return Ok(credentail); 
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message); 
            }

        }*/


        [HttpGet(("Logindetails"))]
        public async Task<ActionResult<Credentail>> GetByEmail(long phnnumber, string password)
        {

            try
            {
                var rdetails = await _login.GetByEmail(phnnumber, password);
                return Ok(rdetails);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            //return Ok(student);

        }

    }

}