﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TourismManagement.Models;
using TourismManagement.Services;
using TourismManagement.Services.Interface;

namespace TourismManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PackageController : ControllerBase
    {
        public IPackage _package;

        public PackageController(IPackage package)
        {
            _package = package;
        }

        [HttpGet]
        public async Task<ActionResult<List<PackageDetail>>> GetAllPackages()
        {
            var packages = await _package.GetAllPackages();
            if (packages == null)
            {
                return NotFound("Not Found");
            }
            else
            {
                return Ok(packages);
            }
        }
        [HttpGet(("Packagename"))]
        public async Task<ActionResult<PackageDetail>> GetByPackageName(string packagename)
        {

            try
            {
                var rpackage = await _package.GetByPackageName(packagename);
                return Ok(rpackage);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            //return Ok(student);

        }

        [HttpGet(("Regionname"))]
        public async Task<ActionResult<RegionDetail>> GetAllRegionName()
        {

            try
            {
                var rregion = await _package.GetAllRegionName();
                return Ok(rregion);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            //return Ok(student);

        }


         [HttpPost]
         public async Task<ActionResult<PackageDetail>> AddPackages(PackageDetail packageDetails)
         {

             var packages = await _package.AddPackages(packageDetails);
             return Ok(packages);
         }

       


        [HttpPut]
        public async Task<ActionResult<List<PackageDetail>>> UpdatePackages(string packagename, PackageDetail packageDetail)
        {

            try
            {
                var rpackages = await _package.UpdatePackages(packagename, packageDetail);
                return Ok(rpackages);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            //return Ok(student);

        }
        [HttpDelete]
        public async Task<ActionResult<List<PackageDetail>>> DeletePackages(string packagename)
        {

            try
            {
                var rpackage = await _package.DeletePackages(packagename);
                return Ok(rpackage);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            //return Ok(student);

        }

    }
}
