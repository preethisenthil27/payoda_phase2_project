﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TourismManagement.Models;
using TourismManagement.Services.Interface;

namespace TourismManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {

        public ISearch _search;

        public SearchController(ISearch search)
        {
            _search = search;
        }



        [HttpGet]
        public async Task<ActionResult<List<PackageDetail>>> Search(string searchelement)
        {
            try
            {

                var ppackages = await _search.SearchByPackages(searchelement);
                int pcount = Convert.ToInt32(ppackages.Count);
                if(pcount==0)   
                {
                    var rpackages = await _search.SearchByRegions(searchelement);
                    return Ok(rpackages);
                }
                else
                {
                    return Ok(ppackages);
                }
                
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           

        }
        
       
        
    }
}
