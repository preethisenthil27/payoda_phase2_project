﻿namespace StudentDetails.Global_Exception
{
    public class StudentDetailsExceptions:Exception
    {

        public static List<string> ExceptionMessages { get;}=
            new List<string>
            {
                "Package Not Found",
                "Region Not Found",
                "Invalid Credentials"
            };
    }
}
