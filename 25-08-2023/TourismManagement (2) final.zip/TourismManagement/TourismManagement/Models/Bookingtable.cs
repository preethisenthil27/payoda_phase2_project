﻿namespace TourismManagement.Models
{
    public class Bookingtable
    {
        
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public int BookingId { get; set; }
       public int?  NoofPer { get; set; }
        public DateTime? BookingDate { get; set; }
        public int PackageId { get; set; }
        public string PackageName { get; set; }
        public long? PackagePrice { get; set; }

    }
}
