﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TourismManagement.Models;

public partial class Credentail
{
    public int CId { get; set; }

    public string? CName { get; set; }

    public string? CPassword { get; set; }

    public string? CEmail { get; set; }

    public long? PhnNumber { get; set; }
   
    [JsonIgnore]
    public virtual ICollection<BookingDetail> BookingDetails { get; set; } = new List<BookingDetail>();
}
