﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TourismManagement.Models;

public partial class PackageDetail
{
    public int PackageId { get; set; }

    public string? PackageName { get; set; }

    public string? ImageUrl { get; set; }

    public string? PackageDescription1 { get; set; }

    public string? PackageDescription2 { get; set; }

    public string? PackageDescription3 { get; set; }

    public string? SpotName { get; set; }

    public int? RegionId { get; set; }

    public long? PackagePrice { get; set; }

    public string? PackageDuration { get; set; }

    [JsonIgnore]
    public virtual ICollection<BookingDetail> BookingDetails { get; set; } = new List<BookingDetail>();
    
    [JsonIgnore]
    public virtual RegionDetail? Region { get; set; }
}
