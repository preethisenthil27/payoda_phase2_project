﻿namespace TourismManagement.Models
{
    public class PackageWithRegion
    {
         public string PackageName { get; set; }
        public string PackageDuration { get; set; }
        public long? PackagePrice { get; set; }
        public string  RegionName { get; set;}
        public string SpotName { get; set; }
        /*
        public PackageDetail Package { get; set; }
        public RegionDetail Region { get; set; }
     

*/
    }
}
