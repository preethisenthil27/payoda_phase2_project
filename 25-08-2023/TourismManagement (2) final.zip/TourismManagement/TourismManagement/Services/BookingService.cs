﻿using Microsoft.EntityFrameworkCore;
using TourismManagement.Models;
using TourismManagement.Services.Interface;

namespace TourismManagement.Services
{
    public class BookingService:IBooking
    {
        public TourismManagementContext _tourismManagementContext;

        public BookingService(TourismManagementContext tourismManagementContext)
        {
            _tourismManagementContext = tourismManagementContext;
        }

        public async Task<List<BookingDetail>> AddBooking(BookingDetail bookingDetails)
        {
            _tourismManagementContext.BookingDetails.Add(bookingDetails);
            await _tourismManagementContext.SaveChangesAsync();
            return await _tourismManagementContext.BookingDetails.ToListAsync();

        }

        public async Task<List<Bookingtable>> GetBookingsByCustomerNameAsync(string customerName)
        {
            var query = from c in _tourismManagementContext.Credentails
                        join b in _tourismManagementContext.BookingDetails on c.CId equals b.CId
                        join p in _tourismManagementContext.PackageDetails on b.PackageId equals p.PackageId
                        where c.CName == customerName
                        select new Bookingtable
                        {
                            CustomerName = customerName,
                            BookingId = b.BookingId,
                            BookingDate = b.BookingDate,
                            CustomerEmail=c.CEmail,
                            PackageId = p.PackageId,
                            NoofPer=b.NoOfPersons,
                            PackageName = p.PackageName,
                            PackagePrice = b.BookingPrice
                        };

            return await query.ToListAsync();
        }
    }
}
