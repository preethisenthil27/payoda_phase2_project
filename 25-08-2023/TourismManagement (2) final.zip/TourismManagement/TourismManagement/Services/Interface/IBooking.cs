﻿using TourismManagement.Models;

namespace TourismManagement.Services.Interface
{
    public interface IBooking
    {
        Task<List<BookingDetail>> AddBooking(BookingDetail bookingDetails);
        Task <List<Bookingtable>> GetBookingsByCustomerNameAsync(string customerName);
       
    }
}
