﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using TourismManagement.Models;

namespace TourismManagement.Services.Interface
{
    public interface ILogin
    {
        Task<List<Credentail>> RegisterDetails(Credentail userDetails);

      
        Task<Credentail> GetByEmail(long phnnumber, string password);
    }
}
