﻿using Microsoft.AspNetCore.Mvc;
using TourismManagement.Models;

namespace TourismManagement.Services.Interface
{
    public interface IPackage
    {
        Task<List<PackageDetail>> GetAllPackages();
        Task<PackageDetail> GetByPackageName(string packagename);
        Task<List<RegionDetail>> GetAllRegionName();
        Task<List<PackageDetail>> AddPackages(PackageDetail packageDetails);

        Task<List<PackageDetail>> UpdatePackages(string packagename, PackageDetail packageDetail);
        Task<List<PackageDetail>> DeletePackages(string packagename);

    }
}
