﻿using TourismManagement.Models;

namespace TourismManagement.Services.Interface
{
    public interface ISearch
    {
        
      Task<List<PackageWithRegion>> SearchByPackages(string packagename);
       
      Task<List<PackageWithRegion>> SearchByRegions(string regionname);
       
       
            
    }
}
