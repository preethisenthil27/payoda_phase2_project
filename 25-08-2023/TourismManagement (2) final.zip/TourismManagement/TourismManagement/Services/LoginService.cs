﻿using Microsoft.EntityFrameworkCore;
using NuGet.Protocol.Plugins;
using StudentDetails.Global_Exception;
using TourismManagement.Models;
using TourismManagement.Services.Interface;

namespace TourismManagement.Services
{
    public class LoginService:ILogin
    {
        public TourismManagementContext _tourismManagementContext;

        public LoginService(TourismManagementContext tourismManagementContext)
        {
            _tourismManagementContext = tourismManagementContext;
        }
        
        public async Task<List<Credentail>> RegisterDetails(Credentail userDetails)
        {
            _tourismManagementContext.Credentails.Add(userDetails);
            await _tourismManagementContext.SaveChangesAsync();
            return await _tourismManagementContext.Credentails.ToListAsync();

        }
        /*
        public async Task<Credentail> Logindetails(Login login)
        {

            var details = await _tourismManagementContext.Credentails.FindAsync(u => u.CEmail.Equals(login.email));
            Credentail result = new Credentail();
            if(details!=null)
            {
                result.CId=details.CId;
                result.CEmail=details.CEmail;
                result.CName=details.CName; 
                result.PhnNumber=details.PhnNumber;
                result.CPassword=details.CPassword;
                return result;
            }
            else
            {
                throw new Exception(StudentDetailsExceptions.ExceptionMessages[0]);
            }

        }*/
        public async Task<Credentail> GetByEmail(long phnnumber, string password)
        {
            Credentail rdetails = await _tourismManagementContext.Credentails.FirstOrDefaultAsync(u => u.PhnNumber.Equals(phnnumber) && u.CPassword.Equals(password));

           
            if (rdetails == null)
            {
                throw new Exception(StudentDetailsExceptions.ExceptionMessages[2]);

            }
            else
            {
                return rdetails;
            }
        }

    }
}
