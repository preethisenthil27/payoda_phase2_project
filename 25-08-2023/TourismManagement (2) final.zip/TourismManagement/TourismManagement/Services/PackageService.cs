﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentDetails.Global_Exception;
using TourismManagement.Models;
using TourismManagement.Services.Interface;

namespace TourismManagement.Services
{
    public class PackageService : IPackage
    {
        public TourismManagementContext _tourismManagementContext;

        public PackageService(TourismManagementContext tourismManagementContext)
        {
            _tourismManagementContext = tourismManagementContext;
        }
        public async Task<List<PackageDetail>> GetAllPackages()
        {
            var response = await _tourismManagementContext.PackageDetails.ToListAsync();
            return response;
        }

       public async Task<List<RegionDetail>> GetAllRegionName()
        {
            var response = await _tourismManagementContext.RegionDetails.ToListAsync();
            return response;
        }

         public async Task<List<PackageDetail>> AddPackages(PackageDetail packageDetails)
         {
             _tourismManagementContext.PackageDetails.Add(packageDetails);
             await _tourismManagementContext.SaveChangesAsync();
             return await _tourismManagementContext.PackageDetails.ToListAsync();

         }
      
      public async Task<List<PackageDetail>> UpdatePackages(string packagename, PackageDetail packageDetail)
        {
            PackageDetail rpackage = await _tourismManagementContext.PackageDetails.FirstOrDefaultAsync(p => p.PackageName == packagename);
            //PackageDetail rpackage = await _tourismManagementContext.PackageDetails.FindAsync(packagename);
            if (rpackage == null)
            {
                throw new Exception(StudentDetailsExceptions.ExceptionMessages[0]);
                
            }
            else
            {
                rpackage.PackageName = packageDetail.PackageName;
                rpackage.PackageDescription1 = packageDetail.PackageDescription1;
                rpackage.PackageDescription2 = packageDetail.PackageDescription2;
                rpackage.PackageDescription3 = packageDetail.PackageDescription3;
                rpackage.PackageDuration = packageDetail.PackageDuration;
                rpackage.PackagePrice = packageDetail.PackagePrice;
                await _tourismManagementContext.SaveChangesAsync();
                // rstudent= await _studentContext.Students.FindAsync(rollno);
                return await _tourismManagementContext.PackageDetails.ToListAsync();
                //return await _studentContext.Students.ToListAsync();
            }
        }

        public async Task<PackageDetail>GetByPackageName(string packagename)
        {
            var rpackage = await _tourismManagementContext.PackageDetails.FirstOrDefaultAsync(p => p.PackageName == packagename);
            //PackageDetail rpackage = await _tourismManagementContext.PackageDetails.FindAsync(packagename);
            if (rpackage == null)
            {
                throw new Exception(StudentDetailsExceptions.ExceptionMessages[0]);

            }
            else
            {

              //  _tourismManagementContext.Remove(rpackage);
                //await _tourismManagementContext.SaveChangesAsync();
                // rstudent= await _studentContext.Students.FindAsync(rollno);
                return rpackage;
                //return await _studentContext.Students.ToListAsync();
            }
        }

        public async Task<List<PackageDetail>> DeletePackages(string packagename)
        {
            //PackageDetail rpackage = await _tourismManagementContext.PackageDetails.FindAsync(packagename);
            PackageDetail rpackage = await _tourismManagementContext.PackageDetails.FirstOrDefaultAsync(p => p.PackageName == packagename);

            if (rpackage == null)
            {
                throw new Exception(StudentDetailsExceptions.ExceptionMessages[0]);
            }
            else
            {

                _tourismManagementContext.Remove(rpackage);
                await _tourismManagementContext.SaveChangesAsync();
                // rstudent= await _studentContext.Students.FindAsync(rollno);
                return await _tourismManagementContext.PackageDetails.ToListAsync();
                //return await _studentContext.Students.ToListAsync();
            }
        }

    }
}
