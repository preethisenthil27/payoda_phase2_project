﻿using Microsoft.EntityFrameworkCore;
using StudentDetails.Global_Exception;
using TourismManagement.Models;
using TourismManagement.Services.Interface;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace TourismManagement.Services
{
    public class SearchService : ISearch
    {
        public TourismManagementContext _tourismManagementContext;

        public SearchService(TourismManagementContext tourismManagementContext)
        {
            _tourismManagementContext = tourismManagementContext;
        }
        public async Task<List<PackageWithRegion>> SearchByPackages(string packagename)
        {
            var combinedData = from package in _tourismManagementContext.PackageDetails
                               join region in _tourismManagementContext.RegionDetails
                               on package.RegionId equals region.RegionId
                               
                               where package.PackageName.Contains(packagename)
                               select new PackageWithRegion
                               {
                                   PackageName = package.PackageName,
                                   PackageDuration = package.PackageDuration,
                                   PackagePrice = package.PackagePrice,
                                   RegionName = region.RegionName,
                                   SpotName = package.SpotName
                               };

            List<PackageWithRegion> result = await combinedData.ToListAsync();
            return result;

        }

        public async Task<List<PackageWithRegion>> SearchByRegions(string regionname)
        {
            var combinedData = from package in _tourismManagementContext.PackageDetails
                               join region in _tourismManagementContext.RegionDetails
                               on package.RegionId equals region.RegionId
                              
                               where region.RegionName.Contains(regionname)
                               select new PackageWithRegion
                               {
                                   PackageName = package.PackageName,
                                   PackageDuration = package.PackageDuration,
                                   PackagePrice = package.PackagePrice,
                                   RegionName = region.RegionName,
                                   SpotName = package.SpotName
                               };

            List<PackageWithRegion> result = await combinedData.ToListAsync();
            return result;


        }



        
    }
}

